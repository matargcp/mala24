---
title : "Testimonials"
description : "this is meta description"
layout : "testimonial"
draft : false

################ Testimonial ###############
testimonial_item:
- name : "Angela Markel"
  image : "images/users/01.jpg"
  designation : "CEO, Angular Corporation"
  content : "Lorem ipsum dolor sit amet, kasd gubergren, seatakimata dolores et rebum stetclita"
  
- name : "Angela Markel"
  image : "images/users/02.jpg"
  designation : "CEO, Angular Corporation"
  content : "Lorem ipsum dolor sit amet, kasd gubergren, seatakimata dolores et rebum stetclita"
  
- name : "Angela Markel"
  image : "images/users/03.jpg"
  designation : "CEO, Angular Corporation"
  content : "Lorem ipsum dolor sit amet, kasd gubergren, seatakimata dolores et rebum stetclita"
  
- name : "Angela Markel"
  image : "images/users/04.jpg"
  designation : "CEO, Angular Corporation"
  content : "Lorem ipsum dolor sit amet, kasd gubergren, seatakimata dolores et rebum stetclita"
  
- name : "Angela Markel"
  image : "images/users/05.jpg"
  designation : "CEO, Angular Corporation"
  content : "Lorem ipsum dolor sit amet, kasd gubergren, seatakimata dolores et rebum stetclita"
  
- name : "Angela Markel"
  image : "images/users/01.jpg"
  designation : "CEO, Angular Corporation"
  content : "Lorem ipsum dolor sit amet, kasd gubergren, seatakimata dolores et rebum stetclita"
  
- name : "Angela Markel"
  image : "images/users/02.jpg"
  designation : "CEO, Angular Corporation"
  content : "Lorem ipsum dolor sit amet, kasd gubergren, seatakimata dolores et rebum stetclita"
  
- name : "Angela Markel"
  image : "images/users/03.jpg"
  designation : "CEO, Angular Corporation"
  content : "Lorem ipsum dolor sit amet, kasd gubergren, seatakimata dolores et rebum stetclita"
  
- name : "Angela Markel"
  image : "images/users/04.jpg"
  designation : "CEO, Angular Corporation"
  content : "Lorem ipsum dolor sit amet, kasd gubergren, seatakimata dolores et rebum stetclita"


##################### Featured Testimonial ################
featured_testimonial:
  enable : false
  name : "Marsh Angela Costa"
  designation : "CEO, Trello"
  quote : "“Copper gives us the ease to have people hop in where they need to, to get to a customer resolution really quickly.”"
  image : "images/testimonials/01.jpg"
  video:
    enable : true
    video_embed_link : "https://www.youtube.com/embed/dyZcRRWiuuw"
---

## What Our **Client says**
Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat sed.