---
title : "Career"
description : "this is meta description"
draft : false

################ Intro #########################
intro:
  enable : true
  title : "Create a world where anyone **belong anywhere**"
  image : "images/career/01.jpg"
  content : "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Purus nc, ornare sem egestas sit purus
  felis arcu. Vitae, turpis tortor etiam faucibus ac suspendisse Tellus.Habit building in essential steps choose habit Good Things Start building habit with Habitify on platform to new"
  button:
    enable : true
    label : "Join Team"
    link : "#join-team"


################ Flexibility ####################
flexibility:
  enable : true
  title : "Flexibility to do your **best work from anywhere**"
  content : "Lorem ipsum sadip dolor sit amet, consetetur sadip scing elitr, diam nonumy eirmod tempor invi duntut labore et dolore magna aliquyam erat, sed diam"
  item:
  - name : "Value add"
    icon : "fas fa-hand-holding-usd"
    content : "Lorem ipsum dolor sit amet, adipiscing purus nc, ornare sem egestas sit purus felis arcu. Vitae, turpis tortor faucibus ac suspendisse. Habit building inessential steps choose habit Good Things Start building something."
    
  - name : "Refference"
    icon : "fas fa-link"
    content : "Lorem ipsum dolor sit amet, adipiscing purus nc, ornare sem egestas sit purus felis arcu. Vitae, turpis tortor faucibus ac suspendisse. Habit building inessential steps choose habit Good Things Start building something."
    
  - name : "Experienced"
    icon : "fas fa-thumbs-up"
    content : "Lorem ipsum dolor sit amet, adipiscing purus nc, ornare sem egestas sit purus felis arcu. Vitae, turpis tortor faucibus ac suspendisse. Habit building inessential steps choose habit Good Things Start building something."
    
  - name : "Meaningful"
    icon : "fas fa-award"
    content : "Lorem ipsum dolor sit amet, adipiscing purus nc, ornare sem egestas sit purus felis arcu. Vitae, turpis tortor faucibus ac suspendisse. Habit building inessential steps choose habit Good Things Start building something."


################ Benifit ####################
benifits:
  enable : true
  title : "Benifits Of **Joining Our Team**"
  content : "Lorem ipsum sadip dolor sit amet, consetetur sadip scing elitr, diam nonumy eirmod tempor invi duntut labore et dolore magna aliquyam erat, sed diam"
  item:
  - name : "Annual travel and <br>credit Too"
    icon : "fas fa-lock"
    content : "Lorem ipsum dolor sit amet, consectetur adipisc Nullam sit vel egestas in. Duis orci, suspendisse nec phasellus sapien natoque "
    
  - name : "Healthy food <br>and snacks"
    icon : "fas fa-magnet"
    content : "Lorem ipsum dolor sit amet, consectetur adipisc Nullam sit vel egestas in. Duis orci, suspendisse nec phasellus sapien natoque "
    
  - name : "Comprehensive <br>health plans"
    icon : "fas fa-link"
    content : "Lorem ipsum dolor sit amet, consectetur adipisc Nullam sit vel egestas in. Duis orci, suspendisse nec phasellus sapien natoque "
    
  - name : "Healthy food <br>and snacks"
    icon : "fas fa-magnet"
    content : "Lorem ipsum dolor sit amet, consectetur adipisc Nullam sit vel egestas in. Duis orci, suspendisse nec phasellus sapien natoque "
    
  - name : "Annual travel and <br>credit Too"
    icon : "fas fa-link"
    content : "Lorem ipsum dolor sit amet, consectetur adipisc Nullam sit vel egestas in. Duis orci, suspendisse nec phasellus sapien natoque "
    
  - name : "Comprehensive <br>health plans"
    icon : "fas fa-lock"
    content : "Lorem ipsum dolor sit amet, consectetur adipisc Nullam sit vel egestas in. Duis orci, suspendisse nec phasellus sapien natoque "
    

#################### Gallery #####################
gallery:
  enable : true
  item:
  - image : "images/career/life-at/01.jpg"
    width : "6"
  - image : "images/career/life-at/02.jpg"
    width : "4"
  - image : "images/career/life-at/03.jpg"
    width : "2"
  - image : "images/career/life-at/04.jpg"
    width : "2"
  - image : "images/career/life-at/05.jpg"
    width : "4"
  - image : "images/career/life-at/06.jpg"
    width : "6"
---

## Join our **growing team**
Lorem ipsum sadip dolor sit amet, consetetur sadip scing elitr, diam nonumy eirmod tempor invi duntut labore
et dolore magna aliquyam erat, sed diam