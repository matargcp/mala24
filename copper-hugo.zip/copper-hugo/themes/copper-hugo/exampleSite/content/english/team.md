---
title : "Team"
description : "this is meta description"
layout : "team"
draft : false

team_member:
- name : "Angelina Jolie"
  image : "images/team/01.jpg"
  designation : "Senior Developer"
  group : "developers"
  social:
  - icon : "fab fa-linkedin"
    link : "#"
  - icon : "fab fa-twitter"
    link : "#"
  - icon : "fab fa-github"
    link : "#"

- name : "Juley anle"
  image : "images/team/02.jpg"
  designation : "Senior Designer"
  group : "designers"
  social:
  - icon : "fab fa-linkedin"
    link : "#"
  - icon : "fab fa-twitter"
    link : "#"
  - icon : "fab fa-github"
    link : "#"
    
- name : "Kim Domingo"
  image : "images/team/03.jpg"
  designation : "Email Marketer"
  group : "marketers"
  social:
  - icon : "fab fa-linkedin"
    link : "#"
  - icon : "fab fa-twitter"
    link : "#"
  - icon : "fab fa-github"
    link : "#"
    
- name : "Angelina Jolie"
  image : "images/team/04.jpg"
  designation : "Junior Developer"
  group : "developers"
  social:
  - icon : "fab fa-linkedin"
    link : "#"
  - icon : "fab fa-twitter"
    link : "#"
  - icon : "fab fa-github"
    link : "#"
    
- name : "Tim kook"
  image : "images/team/05.jpg"
  designation : "UX/UI Designer"
  group : "designers"
  social:
  - icon : "fab fa-linkedin"
    link : "#"
  - icon : "fab fa-twitter"
    link : "#"
  - icon : "fab fa-github"
    link : "#"
    
- name : "John Domingo"
  image : "images/team/06.jpg"
  designation : "SEO Marketer"
  group : "marketers"
  social:
  - icon : "fab fa-linkedin"
    link : "#"
  - icon : "fab fa-twitter"
    link : "#"
  - icon : "fab fa-github"
    link : "#"
---

## Our **Team members**
Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat sed.