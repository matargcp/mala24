---
title : "How It Works"
description : "this is meta description"
layout : "how-it-works"
draft : false
---

{{< section-1 image="images/screenshots/how-it-works-1.jpg">}}
## Task **Management**
Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat sed. At vero eos et accusam et justo duo dolores etea
{{</ section-1 >}}

{{< section-2 image="images/screenshots/03.png">}}
## Collaborative **Tasks**
Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat sed. At vero eos et accusam et justo duo dolores etea
{{</ section-1 >}}

{{< section-1 image="images/screenshots/04.png">}}
## Built-in **Documents**
Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat sed. At vero eos et accusam et justo duo dolores etea
{{</ section-1 >}}