---
title : "Services"
description : "this is meta description"
layout : "services"
draft : false

services:
- name : "Attached coache"
  icon : "fas fa-paperclip"
  content : "Lorem ipsum dolor , consetetur sadipscing gfed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat."

- name : "Instant Notification"
  icon : "fas fa-bell"
  content : "Lorem ipsum dolor , consetetur sadipscing gfed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat."
  
- name : "Live Attachment"
  icon : "fas fa-clipboard"
  content : "Lorem ipsum dolor , consetetur sadipscing gfed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat."
  
- name : "Instant Notification"
  icon : "fas fa-bell"
  content : "Lorem ipsum dolor , consetetur sadipscing gfed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat."
  
- name : "Live Attachment"
  icon : "fas fa-clipboard"
  content : "Lorem ipsum dolor , consetetur sadipscing gfed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat."
  
- name : "Attached coache"
  icon : "fas fa-paperclip"
  content : "Lorem ipsum dolor , consetetur sadipscing gfed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat."
---

## Our **Services**
Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat sed.