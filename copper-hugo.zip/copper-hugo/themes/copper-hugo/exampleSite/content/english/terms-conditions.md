---
title : "Terms & Conditions"
description : "this is meta description"
layout : "regular"
draft : false
---

### GDPR Compliance
Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat sed.

We collect certain identifying personal data when you sign up to our Service such as your name, email
address, PayPal address (if different from email address), and telephone number. The personal data we
collect from you is disclosed only in accordance with our Terms of Service and/or this Privacy
Policy.Conclude collects Slack account and access information from Users for the purposes of connecting to
the Slack API and to authenticate access to information on the Conclude website. Whenever you visit our
Site, we may collect non-identifying information from you, such as referring URL, browser, operating system,
cookie information, and Internet Service Provider. Without a subpoena, voluntary compliance on the part of
your Internet Service Provider, or additional records from a third party, this information alone cannot
usually be used to identify you.The term "personal data" does not include any anonymized and aggregated data
made on the basis of personal data, which are wholly owned by Conclude.

### About Copper
##### Service Provided As:
The Service is provided for free during this pilot project, and is provided "as is" with
no warranty. Conclude will provide User support for the Service, however; Conclude is not committed to any
level of service or availability of the Service. A further description of the Service and our user support
is available at the Site. contact at [hello@Copper.com](mailto:hello@Copper.com)


##### Company Liability:
If you enter into this agreement on behalf of a company, you hereby agree that the company is responsible
under this Agreement for all actions and omissions conducted by its designated users of the Service.

### When we collect personal data about you

* Enhance or improve User experience, our Site, or our Service.
* Send emails and updates about Conclude, Process transactions.
* Send emails about our Site or respond to inquiries.
* Including news and requests for agreement to amended legal documents such as this Privacy Policy and our Terms of Service.

### Why we collect and use personal data
Users of Conclude (i) must keep passwords secure and confidential; (ii) are solely responsible for User
Data and all activity in their account while using the Service; (iii) must use commercially reasonable
efforts access to their account, and notify Conclude promptly of any such unauthorized access; and (iv) may
use the Service only in accordance with Conclude's online user guide and all applicable laws and
regulations.