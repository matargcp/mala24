---
title : "Pricing"
description : "this is meta description"
layout : "pricing"
offer : "Save 50% On Annual Subscription"
# you can set only monthly, only yearly, or toggle both
monthly_yearly_toggle: "toggle" # available value "monthly"/"yearly"/"toggle"
draft : false


# pricing card
pricing_card:
# pricing table
- name : "Team"
  content : "Lorem ipsum dolor sit amet, confsectur justo. Massa augue neque proin adipisng."
  currency: "$"
  monthly_price : "39"
  yearly_price : "139"
  featured : false
  button_label : "Start Free Trial"
  button_link : "#"
  services:
  - "Track Reward Part Program"
  - "Design and prototype powerful"
  - "Keep work in unlimited storage"
  - "Add people document handoff."
  
# pricing table
- name : "Business"
  content : "Lorem ipsum dolor sit amet, confsectur justo. Massa augue neque proin adipisng."
  currency: "$"
  monthly_price : "99"
  yearly_price : "199"
  featured : true
  button_label : "Start Free Trial"
  button_link : "#"
  services:
  - "Track Reward Part Program"
  - "Design and prototype powerful"
  - "Keep work in unlimited storage"
  - "Add people document handoff."
  
# pricing table
- name : "Enterprise"
  content : "Lorem ipsum dolor sit amet, confsectur justo. Massa augue neque proin adipisng."
  currency: "$"
  monthly_price : "129"
  yearly_price : "229"
  featured : false
  button_label : "Start Free Trial"
  button_link : "#"
  services:
  - "Track Reward Part Program"
  - "Design and prototype powerful"
  - "Keep work in unlimited storage"
  - "Add people document handoff."
---

## Choose **Pricing**
Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat sed.