---
title : "Changelog"
description : "this is meta description"
layout : "changelog"
draft : false
sidelist:
- "v1.0.4 (January 19,2020)"
- "v1.0.2 (January 10,2020)"
- "v1.0.0 (January 01,2019)"
---

#### v1.0.4 (January 19,2020)

{{< changelog value="changed" class="d-inline-block mb-4">}}
* Process transactions.
* Send emails about our [Site](#)
* Send emails and updates about Conclude
* Perform any other function that we believe
{{</ changelog >}}

{{< changelog value="added" class="d-inline-block mb-4">}}
* Process transactions.
* Send emails about our [Site](#)
* Send emails and updates about Conclude
* Perform any other function that we believe
{{</ changelog >}}


#### v1.0.2 (January 10,2020)

{{< changelog value="removed" class="d-inline-block mb-4">}}
* Process transactions.
* Send emails about our [Site](#)
* Send emails and updates about Conclude
* Perform any other function that we believe
{{</ changelog >}}

{{< changelog value="security" class="d-inline-block mb-4">}}
* Process transactions.
* Send emails about our [Site](#)
* Send emails and updates about Conclude
* Perform any other function that we believe
{{</ changelog >}}


#### v1.0.0 (January 01,2019)

{{< changelog value="added" class="d-inline-block mb-4">}}
* Process transactions.
* Send emails about our [Site](#)
* Send emails and updates about Conclude
* Perform any other function that we believe
{{</ changelog >}}

{{< changelog value="security" class="d-inline-block mb-4">}}
* Process transactions.
* Send emails about our [Site](#)
* Send emails and updates about Conclude
* Perform any other function that we believe
{{</ changelog >}}